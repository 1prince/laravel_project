<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/Data_Structure.php',function(){

	return view('Data_Structure');
});
Route::get('/Algorithm.php',function(){

	return view('Algorithm');
});
Route::get('/mcq.php',function(){

	return view('mcq');
});
Route::get('/Placement_Related_Course.php',function(){

	return view('Placement_Related_Course');
});
Route::get('/aptitude.php',function(){

	return view('aptitude');
});
Route::get('/DBMS.php',function(){

	return view('Dbms');
});
Route::get('/OS.php',function(){

	return view('OS');
});
Route::get('/Network.php',function(){

	return view('Network');
});
Route::get('/c.php',function(){

	return view('c');
});
Route::get('/c++.php',function(){

	return view('c++');
});
Route::get('/java.php',function(){

	return view('java');
});

Route::get('/company_wise.php',function(){

	return view('company_wise');
});
Route::get('/quiz.php',function(){

	return view('quiz');
});
Route::get('/login.blade.php',function(){

	return view('login');
});
Route::get('/register.blade.php',function(){

	return view('register');
});

Route::post('/store','UserController@store');
Route::post('/logs','UserController@logs');	




