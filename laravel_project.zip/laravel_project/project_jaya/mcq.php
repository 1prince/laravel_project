<!DOCTYPE html>
<html>
<head>
<style>
	
	body
	{
		margin:0px;
		padding:0px;

	}
	ul{
		list-style-type: none;
		margin:auto;
		float:left;
		background-color: beige;
		padding:0;
		
	}
	li a
	{
		text-decoration: none;
		color:black;
		font: cursive;
		
	}
	li
	{
		padding-top:20px;
		padding-bottom: 30px;
		min-width:250px;
		text-align:justify;
		padding-left: 9px;
		font-family:monospace;
		box-shadow: 1px 1px darkcyan;
		
		
	}
	ul li:hover
	{
		text-decoration: none;
		background-color:white;
		box-shadow: 2px 2px 2px  darkcyan ;
		border:1px solid grey;
		
	}
	.header
	{
		
		background-color:darkcyan;
		
		
	}
	.header h2,a
	{
		display: inline-block;
		font-family:monospace;
		
	}
	.header .headerlink
	{
		padding:9px;
		text-decoration: none;
		color:white;
		font-size: 20px;
	}
	.header h2
	
	{
		padding-right: 600px;
		padding-left:20px;
		color:white;
	}
	
	.aside
	{
		border-style: ridge;
		border-top:3px solid darkcyan;
		min-width:800px;
		min-height:900px;
		padding:20px;
		margin:20px;
		margin-left: 50px;
		float:left;
		border-radius: 5px;
		background-color:beige;
		
		
	
	}
	.aside:hover
	{
	box-shadow: 10px 10px 5px grey;	
	}

	
	 p
	{
		
		font-size: 18px;
		background-color:darkcyan;
		color:white;
		text-align: center;
		border:5px solid darkcyan;
		border-top-color:darkgoldenrod; 
		font-family: sans-serif;
		
	}
	.footer
	{
		width:100%;
		background-color: darkcyan;
		border:5px solid darkcyan;
		border-top-color:darkgoldenrod;
		height:250px;
		margin-top:1020px;
		
	}
	.active:hover
	{
		background-color: white;
	}
	
</style>
<tittle>
</tittle>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="header">
	<h2> PlacementPrePortal <span class="glyphicon glyphicon-thumbs-up"></span></h2>
	<a class="headerlink" href=""><span class="glyphicon glyphicon-earphone"></span> Contact</a>
	<a class="headerlink" href=""><span class="glyphicon glyphicon-log-out"></span> LogOut</a>
</div>	

<ul>
<li><a href="Placement_Related_Course.php" >Placement Related Courses</a></li>	
<li><a href="Data_Structure.php" >Practice Data Structure</a></li>	
<li><a href="Algorithm.php" >Practice Algorithm</a></li>	
<li><a href="mcq.php" class="active">MCQ Questions</a></li>	
<li><a href="aptitude.php">Aptitude Question</a></li>	
<li><a href="DBMS.php">DBMS Subject</a></li>	
<li><a href="OS.php">OS Subject</a></li>	
<li><a href="Network.php">Networking Subject</a></li>	
<li><a href="c.php">C Programmimg</a></li>	
<li><a href="c++.php">C++ Programming</a></li>	
<li><a href="java.php">Java</a></li>
<li><a href="company_wise.php">Company Wise Question</a></li>
<li><a href="quiz.php">Take Quiz</a></li>
</ul>


<div class="aside">


</div>

	
<footer>
	<div class ="footer">
	<table style="color:white ;">
		
	<tr>
	
	
	<th>
	<h1 style="margin-left:20px">PlacementPrePortal</h1>
	<h4 style="margin-left:20px; font-family:cursive;">Prepare here for your dream company</h4>
	<br><br>	
	    <h5 style="margin-left:30px">
			Lovely Professional University<br>
			Jalandhar, Punjab<br>
			code 144111<br>
			jayasinghrajput2016@gmail.com<br>
		</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">WEBSITE</h3>
	<h5 style="margin-left:90px; "> 
	About Us<br>
	Privacy Policy<br>
	Contact Us<br>
	Careers
		
	</h5>
	</th>
	<th>
	<h3 style="margin-left:90px; ">LEARN</h3>
	<h5 style="margin-left:90px; "> 
	Algorithm<br>
	DataStructure<br>
	CS Subject<br>
	languages
		
	</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">PRACTICE</h3>
	<h5 style="margin-left:90px; "> 
	Courses<br>
	Company-wise<br>
	Topic-wise<br>
	How to begin?
		
	</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">CONTRIBUTE</h3>
	<h5 style="margin-left:90px; "> 
	Write an Article<br>
	Interview Experiance<br>
	Internship<br>
	Video
		
	</h5>
	</th>
		
	</tr>
		
	</table>
	</div>
</footer>
</body>
</html>