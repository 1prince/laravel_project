<!DOCTYPE html>
<html>
<head>
<style>
	
	body
	{
		margin:0px;
		padding:0px;

	}
	ul{
		list-style-type: none;
		margin:auto;
		float:left;
		background-color: beige;
		padding:0;
		
	}
	li a
	{
		text-decoration: none;
		color:black;
		font: cursive;
		
	}
	li
	{
		padding-top:20px;
		padding-bottom: 30px;
		min-width:250px;
		text-align:justify;
		padding-left: 9px;
		font-family:monospace;
		box-shadow: 1px 1px darkcyan;
		
		
	}
	ul li:hover
	{
		text-decoration: none;
		background-color:white;
		box-shadow: 2px 2px 2px  darkcyan ;
		border:1px solid grey;
		
	}
	.header
	{
		
		background-color:darkcyan;
		
		
	}
	.header h2,a
	{
		display: inline-block;
		font-family:monospace;
		
	}
	.header .headerlink
	{
		padding:9px;
		text-decoration: none;
		color:white;
		font-size: 20px;
	}
	.header h2
	
	{
		padding-right: 600px;
		padding-left:20px;
		color:white;
	}
	
	.aside
	{
		border-style: ridge;
		border-top:3px solid darkcyan;
		width:800px;
		height:200px;
		padding:20px;
		margin:20px;
		margin-left: 50px;
		float:left;
		border-radius: 5px;
		
		
	
	}
	.aside:hover
	{
	box-shadow: 10px 10px 5px grey;	
	}
	
	
	 p
	{
		
		font-size: 18px;
		background-color:darkcyan;
		color:white;
		text-align: center;
		border:5px solid darkcyan;
		border-top-color:darkgoldenrod; 
		font-family: sans-serif;
		
	}
	.footer
	{
		width:auto;
		background-color: darkcyan;
		border:5px solid darkcyan;
		border-top-color:darkgoldenrod;
		height:250px;
		margin-top:1020px;
		
	}
@media only screen and (max-width: 1800px) 
{
	.header h2
	
	{
		padding-right: 460px;
	
	}
	
}
@media only screen and (max-width: 1200px) {
  .aside
	{
		max-width: 790px;
		margin:auto;
		
		
		
	}
	
	

.header h2
	
	{
		padding-right: 430px;
		padding-left:20px;
		color:white;
	}
	
	
	}
@media only screen and (max-width: 1090px) {
  .aside
	{
		max-width: 720px;
		margin:auto;
		
		
		
	}


.header h2
	
	{
		padding-right: 370px;
	
	}
	}
@media only screen and (max-width: 1000px) {
  .aside
	{
		max-width: 700px;
		margin:auto;
		
		
		
	}
	.header h2
	
	{
		padding-right: 330px;
	}
	}
@media only screen and (max-width: 990px) {
  .aside
	{
		max-width: 680px;
		margin:auto;
		
		
		
	}
	.header h2
	
	{
		padding-right: 300px;
	}
	
	}
@media only screen and (max-width: 950px) {
  .aside
	{
		max-width: 650px;
		margin:auto;
		
		
		
	}
	.header h2
	
	{
		padding-right: 200px;
	}
	}
@media only screen and (max-width: 930px) {
  .aside
	{
		max-width: 630px;
		margin:auto;
		
		
		
	}
	.header h2
	
	{
		padding-right: 150px;
	}
	}
@media only screen and (max-width: 900px) {
  .aside
	{
		max-width: 600px;
		margin:auto;
		
		
		
	}}
@media only screen and (max-width: 880px) {
  .aside
	{
		max-width: 590px;
		margin:auto;
		
		
		
	}}
@media only screen and (max-width: 850px) {
  .aside
	{
		max-width: 550px;
		margin:auto;
		height:auto;
		
		
		
	}}
@media only screen and (max-width: 820px) {
  .aside
	{
		max-width: 500px;
		margin:auto;
		height:auto;
		
		
		
	}}
@media only screen and (max-width: 790px) {
  .aside
	{
		max-width: 490px;
		margin:auto;
		height:auto;
		
		
		
	}}
	
	@media only screen and (max-width: 760px) {
  .aside
	{
		max-width: 470px;
		margin:auto;
		height:auto;
		
		
		
	}}
	@media only screen and (max-width: 730px) {
  .aside
	{
		max-width: 420px;
		margin:auto;
		height:auto;
		
		
		
	}}
	@media only screen and (max-width: 700px) {
  .aside
	{
		max-width: 400px;
		margin:auto;
		height:auto;
		
		
		
	}}
	@media only screen and (max-width: 680px) {
  .aside
	{
		max-width: 380px;
		margin:auto;
		height:auto;
		
		
		
	}}
	@media only screen and (max-width: 650px) {
  .aside
	{
		max-width: 350px;
		margin:auto;
		height:auto;
		
		
		
	}}@media only screen and (max-width: 620px) {
  .aside
	{
		max-width: 320px;
		margin:auto;
		height:auto;
		
		
		
	}
	.footer
	{
		display: none;
	}
	
	}
	@media only screen and (max-width: 500px) {
  .aside
	{
		max-width: 300px;
		margin:auto;
		height:auto;
		
		
		
	}
	.footer
	{
		display: none;
	}
	
	}

@media only screen and (max-width: 499px) {
  .aside
	{
		
		height:auto;
		
		
		
		
	}
.footer
	{
		display: none;
	}
	
	}



 




	


	



</style>
	
<tittle>
</tittle>

<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="header">
	<h2> PlacementPrePortal <span class="glyphicon glyphicon-thumbs-up"></span></h2>
	<a class="headerlink" href=""><span class="glyphicon glyphicon-earphone"></span> Contact</a>
	<a class="headerlink" href=""><span class="glyphicon glyphicon-log-out"></span> LogOut</a>
</div>	

<ul>
<li><a href="Placement_Related_Course.php"  >Placement Related Courses</a></li>	
<li><a href="Data_Structure.php" >Practice Data Structure</a></li>	
<li><a href="Algorithm.php" >Practice Algorithm</a></li>	
<li><a href="mcq.php">MCQ Questions</a></li>	
<li><a href="aptitude.php">Aptitude Question</a></li>	
<li><a href="DBMS.php">DBMS Subject</a></li>	
<li><a href="OS.php">OS Subject</a></li>	
<li><a href="Network.php">Networking Subject</a></li>	
<li><a href="c.php">C Programmimg</a></li>	
<li><a href="c++.php">C++ Programming</a></li>	
<li><a href="java.php">Java</a></li>
<li><a href="company_wise.php">Company Wise Question</a></li>
<li><a href="quiz.php">Take Quiz</a></li>
</ul>


<div class="aside">
<p>Overveiw of how to start learning</p>
	<h5>
		
	Instruction about how to begin your preparation step by step:-
	<br>
	<br>
		
	<b>1.Prepare specific to company</b><br>
	a.Go to the company wise block
	<br><br>
	<b>2.Prepare by prioritizing all </b>
	<br>
	a.Then go to every block in left side
	

	</h5>

</div>
<div class="aside">
	
	
<p>Important Rounds In placement </p>
<h5>
	
<b>The process varied from company to company. But the general procedure is:</b>
<br><br>
1. Written MCQ Round: May be a general maths/puzzle based round and/or CS MCQs.<br>
2.Coding round: 1–3 questions that need to be solved, usually in an environment like Hackerrank or Hackerearth.
<br>
3.Technical interviews : 1–3 rounds of interviews, about programming, theory, languages, etc.
<br>
4.HR round: Interview with HR manager.
</h5>
	
</div>
<div class="aside">
<p>Coding preparation site for begineers</p>
<h5>
	<b>1.HAKERRANK </b>
	<br>
	Path to practice-> Create account->login->Go to practice->Go to all track->There practice 
	<b>basic input output</b> and 
	<br>
	<b>Datastructure and algorithm</b>
	<br><br>
	
	<b>1.HAKEREARTH </b>
	<br>
	Path to practice-> Create account->login->Go to practice->
	<b>Interview preparation</b> 
	and 
	<b>Language specific preparation</b>
	
	
</h5>
</div>

<div class="aside">
<p>Extra Domain preparation to stand out</p>
<h5>
<b>Different domain here :- </b>
<br>
<br>
	1. Go for Android.<br>
	2. Go for Mean stack development.<br>
	3. Data Science.<br>
	4. Big data.<br>
	5. Cyber Security<br>
	6. Machine Learning
</h5>
</div>
	
<footer>
	<div class ="footer">
	<table style="color:white ;">
		
	<tr>
	
	
	<th>
	<h1 style="margin-left:20px">PlacementPrePortal</h1>
	<h4 style="margin-left:20px; font-family:cursive;">Prepare here for your dream company</h4>
	<br><br>	
	    <h5 style="margin-left:30px">
			Lovely Professional University<br>
			Jalandhar, Punjab<br>
			code 144111<br>
			jayasinghrajput2016@gmail.com<br>
		</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">WEBSITE</h3>
	<h5 style="margin-left:90px; "> 
	About Us<br>
	Privacy Policy<br>
	Contact Us<br>
	Careers
		
	</h5>
	</th>
	<th>
	<h3 style="margin-left:90px; ">LEARN</h3>
	<h5 style="margin-left:90px; "> 
	Algorithm<br>
	DataStructure<br>
	CS Subject<br>
	languages
		
	</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">PRACTICE</h3>
	<h5 style="margin-left:90px; "> 
	Courses<br>
	Company-wise<br>
	Topic-wise<br>
	How to begin?
		
	</h5>
	</th>
		
	<th>
	<h3 style="margin-left:90px; ">CONTRIBUTE</h3>
	<h5 style="margin-left:90px; "> 
	Write an Article<br>
	Interview Experiance<br>
	Internship<br>
	Video
		
	</h5>
	</th>
		
	</tr>
		
	</table>
	</div>
</footer>
</body>
</html>